<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$this->load->helper('url');

		$this->db->select('*');
		$this->db->from('todos');
		$query = $this->db->get();
		$data['alltasks'] = $query->result();

		$this->load->view('add_task',$data);
	}

	public function inserttask()
	{
		if ($_POST) {
			$insertdata['todo_name'] = $_POST['task_name'];
			$insertdata['todo_status'] = 0; //status pending
			$this->db->insert('todos',$insertdata);
			//$this->session->set_flashdata('success','Todo Task added successfully....!');
			$this->index();
		}
	}

	public function deltask()
	{
		$taskid = $this->uri->segment(2);
		$this->db->where('todo_id', $taskid);
		$this->db->delete('todos');
		$this->index();
	}

	public function statuscheck()
	{
		$taskid = $this->uri->segment(2);
		$updatestatus['todo_status'] = 1;
		$this->db->where('todo_id', $taskid);
        $this->db->update('todos', $updatestatus);
		$this->index();
	}
}
