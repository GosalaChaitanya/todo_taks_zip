<style>
table, th, td {
  border:1px solid black;
}
</style>

<h3>Add Task</h3>
<form action="<?=base_url('addtask');?>" method="POST">
<input type="text" name="task_name" placeholder="Task Name"><br><br>
<input type="submit">
</form>

<table style="width:30%">
  <tr>
    <th>S.No</th>
    <th>Task</th>
    <th>Status</th>
    <th>Action</th>
  </tr>
  <?php $sno = 1; foreach ($alltasks as $list) { ?>
  <tr>
    <td><?=$sno++?></td>
    <td><?=$list->todo_name?></td>
    <td><?=$list->todo_status == 0 ? "Pending" : "Completed";?></td>
    <td><a href="<?=base_url('deltask/').$list->todo_id;?>">Delete</a> / <a href="<?=base_url('statuscheck/').$list->todo_id;?>"><?=$list->todo_status == 0 ? "Completed" : "";?></a></td>
  </tr>
  <?php } ?>
</table>
